---
name: geo-microarray-fetch
description: Use when fetching microarray expression data from GEO (Gene Expression Omnibus) database in R, including probe-to-gene aggregation, multi-platform support (Affymetrix/Agilent/Illumina), and automatic fallback logic.
---

# Overview

This skill retrieves microarray expression data from Gene Expression Omnibus (GEO) using R/Bioconductor with smart five-tier fallback.

## When to Use

Use this skill when you need to:
- Download gene expression microarray data from GEO
- Process Affymetrix, Agilent, or Illumina arrays
- Convert probe-level to gene-level expression
- Handle missing data with automatic fallback
- Batch download multiple GSE datasets
- Validate expression matrix quality

**Trigger phrases**: "fetch GEO", "download microarray", "get GSE", "GEO expression", "series matrix"

1. **Local data** (skip download if valid data already exists)
2. **Processed series matrix** (fastest, normalized data from GEO)
3. **Suppl pre-processed matrix** (author-provided processed data)
4. **Raw CEL files** (Affymetrix arrays processed with oligo/RMA)
5. **Metadata only** (when no expression data is available)

## Key Features

- Automatic platform detection (Affymetrix, Agilent, Illumina, TXT/CSV)
- Methylation array detection and skip (BPM + IDAT files)
- Multiple GPL handling with per-platform output files
- Probe-to-gene aggregation for gene-level expression
- Smart fallback strategy for maximum data retrieval success rate
- Gene annotation handling with multiple fallback mechanisms

## Supported Platforms
*See [PLATFORMS.md](references/PLATFORMS.md) for detailed platform specifications*

| Platform | Detection | Processing |
|----------|-----------|------------|
| Affymetrix | `*.CEL(.gz)?$` | oligo::rma() |
| Agilent | `*.GPR(.gz)?$` | limma::read.maimages() |
| Illumina | `*.idat` | illuminaio::readIDAT() |
| TXT/CSV | `series_matrix.txt.gz` | Direct import |

## Data Priority

The skill attempts data sources in priority order:

```
┌─────────────────────────────────────────────────────────────┐
│                    DATA FETCH FLOWCHART                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ 1. Local Data?  │
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
              ▼                                 ▼
         YES (use local)               NO ▼
                                        │
                              ┌─────────────────────┐
                              │ 2. Series Matrix?   │
                              └──────────┬──────────┘
                                         │
                      ┌──────────────────┴──────────────────┐
                      ▼                                     ▼
                YES (Tier 2)                          NO ▼
                                                         │
                                               ┌─────────────────────┐
                                               │ 3. Supplementary?   │
                                               └──────────┬──────────┘
                                                          │
                                       ┌─────────────────┴────────────────┐
                                       ▼                                  ▼
                                 YES (Tier 3)                       NO ▼
                                                                  │
                                                        ┌─────────────────────┐
                                                        │ 4. Raw CEL Files?    │
                                                        └──────────┬──────────┘
                                                                   │
                                                        ┌──────────┴──────────┐
                                                        ▼                     ▼
                                                   YES (Tier 4)         NO ▼
                                                                        │
                                                              ┌─────────────────────┐
                                                              │ 5. Metadata Only    │
                                                              └─────────────────────┘
```

1. **Local files** (if valid) → skip download
2. **GEO series matrix** (GSEMatrix=TRUE) → normalized, fast
3. **Suppl matrix files** (*.txt.gz) → author-processed
4. **Raw CEL files** → requires oligo, slower
5. **Metadata only** → when all expression data fails

# Usage

## Command Line

```bash
cd .opencode/skills/geo-microarray-fetch/scripts

# Display help
Rscript fetch_geo.R

# Fetch data
Rscript fetch_geo.R GSE100155
Rscript fetch_geo.R GSE100155 ./output
```

## R Script Integration

```r
# Load required scripts
source(".opencode/skills/geo-microarray-fetch/scripts/platform_detect.R")
source(".opencode/skills/geo-microarray-fetch/scripts/validate.R")
source(".opencode/skills/geo-microarray-fetch/scripts/fetch_geo.R")

# Fetch GEO data
result <- fetch_geo("GSE100155", output_dir = "./output")

# Check result status
if (result$status %in% c("success_local", "success_matrix", "success_suppl", "success_raw")) {
  cat("✅ Successfully fetched data\n")
  cat("Probe file:", result$probe_file, "\n")
  cat("Gene file:", result$gene_file, "\n")
}
```

# Parameters

## Required

- `gse_id` (string): GEO Series identifier (e.g., "GSE100155", "GSE12345")

## Optional

- `output_dir` (string): Directory path for saving downloaded files. Default: current working directory
- `api_key` (string): NCBI API key for higher rate limits (3 requests/second without key, 10 requests/second with key)

# Output

## Return Value

The function returns a list with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `status` | string | Status code: `success_local`, `success_matrix`, `success_suppl`, `success_raw`, `metadata_only`, `skipped_methylation`, `error` |
| `probe_file` | string or NULL | Path to probe-level expression CSV file |
| `gene_file` | string or NULL | Path to gene-level expression CSV file |
| `metadata` | list | Dataset metadata (title, summary, organism, platform, n_samples, n_probes) |
| `warnings` | vector | Non-fatal warnings (fallback events, data quality issues) |
| `errors` | vector | Error messages if status is `error` |

## Status Codes

| Code | Description |
|------|-------------|
| `success_local` | Used existing local data, skipped download |
| `success_matrix` | Successfully retrieved GEO processed series matrix |
| `success_suppl` | Successfully retrieved author-provided processed matrix from suppl directory |
| `success_raw` | Successfully processed raw CEL files with RMA normalization |
| `metadata_only` | Retrieved metadata only (no expression data available) |
| `skipped_methylation` | Dataset contains methylation array data (BPM files), skipped |
| `error` | All data retrieval methods failed |

# Examples

```r
# Load required scripts
source(".opencode/skills/geo-microarray-fetch/scripts/platform_detect.R")
source(".opencode/skills/geo-microarray-fetch/scripts/validate.R")
source(".opencode/skills/geo-microarray-fetch/scripts/fetch_geo.R")

# Fetch GEO data with automatic fallback
result <- fetch_geo("GSE100155", output_dir = "./output")

# Check status and handle accordingly
switch(result$status,
  "success_local" = {
    cat("Using existing local data\n")
  },
  "success_matrix" = {
    cat("Successfully fetched from GEO series matrix\n")
    cat("Probe file:", result$probe_file, "\n")
    cat("Gene file:", result$gene_file, "\n")
    
    # Access metadata
    if (!is.null(result$metadata)) {
      for (plat in names(result$metadata)) {
        m <- result$metadata[[plat]]
        cat("Platform:", plat, "| Samples:", m$n_samples, "| Probes:", m$n_probes, "\n")
      }
    }
  },
  "success_suppl" = {
    cat("Using author-provided supplementary data\n")
  },
  "success_raw" = {
    cat("Processed raw CEL files with RMA\n")
  },
  "metadata_only" = {
    cat("Only metadata available\n")
  },
  "skipped_methylation" = {
    cat("Methylation array - skipped\n")
  },
  "error" = {
    cat("Error:", paste(result$errors, collapse = "; "), "\n")
  }
)

# Handle warnings
if (length(result$warnings) > 0) {
  cat("Warnings:\n")
  for (w in result$warnings) cat(" -", w, "\n")
}

# For multiple platform datasets, files include platform suffix:
# output/GSE12345/expr_gene_GSE12345_GPL570.csv
# output/GSE12345/expr_gene_GSE12345_GPL6244.csv
```

# Error Handling
*See [ERROR_CODES.md](references/ERROR_CODES.md) for detailed error code specifications*

## Common Issues

### 1. Methylation Data Detection

Symptom: Status is `skipped_methylation`

Cause: Dataset contains methylation array files (BPM + IDAT)

Solution:
- Methylation arrays use different data formats
- Use specialized methylation analysis tools
- This skill is designed for expression arrays only

### 2. Network Timeout

Symptom: `error` status with timeout messages

Cause: Network issues or proxy problems

Solution:
- Check proxy configuration (default: `http://localhost:1086`)
- Increase timeout or retry
- Use NCBI API key for higher rate limits

### 3. No Gene Annotation

Symptom: Warning about probe-level only

Cause: GPL annotation not available or gene symbol column missing

Solution:
- Skill uses probe IDs as gene symbols (fallback behavior)
- Check if expression data meets your needs
- Consider downloading GPL separately if needed

### 4. Package Dependencies

Required R packages:
- `GEOquery` - GEO data access
- `Biobase` - Bioconductor data structures
- `dplyr`, `tidyr`, `stringr`, `tibble` - Data manipulation

Optional (for raw CEL processing):
- `oligo` - Affymetrix CEL file processing

Installation:
```r
if (!require("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}

BiocManager::install(c("GEOquery", "Biobase"))
install.packages(c("dplyr", "tidyr", "stringr", "tibble"))

# For raw CEL processing:
BiocManager::install("oligo")
```

## Output Files

The skill generates the following files in the output directory:

```
output/
└── GSE12345/
    ├── expr_probe_GSE12345[_GPL].csv    # Probe-level expression matrix
    ├── expr_gene_GSE12345[_GPL].csv     # Gene-level expression matrix
    └── suppl/                             # Downloaded supplementary files
        ├── GSE12345_RAW.tar
        ├── GSE12345_series_matrix.txt.gz
        └── ...
```

**File formats**:
- **Probe-level CSV**: Probes as rows, samples as columns
- **Gene-level CSV**: Genes as rows, samples as columns (aggregated from probes)

## Gene Annotation Fallback Strategy

The skill implements a robust gene annotation system:

1. **Primary**: Use `fData()` from ExpressionSet with gene symbol column
2. **Secondary**: Check if rownames already are gene symbols
3. **Fallback**: Download GPL annotation and map probes to genes
4. **Last Resort**: Use probe IDs as gene symbols (with warning)

This ensures gene-level expression is available even when GPL annotation is missing.

## Proxy Configuration

The skill supports HTTP proxy for network access:

```r
# The script includes built-in proxy handling
# Default proxy: http://localhost:1086

# To use different proxy, modify proxy_handler in fetch_geo.R
set_proxy <- function(proxy = "http://your-proxy:port")
```

# Troubleshooting

## Debug Mode

To enable verbose output, add `message()` calls in fetch_geo.R or run with:

```r
options(verbose = TRUE)
```

## Validation

The skill includes automatic validation:

- Matrix completeness check (rows > 0, columns > 0)
- Extreme value detection (values > 1e100)
- Data type validation (numeric conversion)
- File integrity checks (for CEL files)

## Integration with Other Skills

This skill works with:
- `geo-microarray-clean` - Downstream data cleaning and processing

## Notes

- **Download caching**: The skill checks for existing local data to avoid re-downloading
- **Rate limiting**: Automatic rate limiting (3 req/sec without API key, 10 req/sec with key)
- **Error recovery**: Multi-tier fallback ensures maximum success rate
- **Platform detection**: Automatic detection based on file patterns
- **Memory efficient**: Processes data in chunks for large datasets

## References

- **GEOquery R package**: https://bioconductor.org/packages/GEOquery/
- **GEO Database**: https://www.ncbi.nlm.nih.gov/geo/
- **Bioconductor**: https://www.bioconductor.org/

## License

This skill is provided for research purposes. Data fetched from GEO is subject to GEO's terms of use.
