# Platform Detection Functions for GEO Microarray Data
# Based on 8-GEO/2-判断数据类型.R detection logic

#' Check if files indicate methylation array data
#'
#' @param files Character vector of filenames
#' @return Logical TRUE if methylation array detected (has BPM files)
#' @examples
#' is_methylation(c("sample1.idat", "manifest.bpm")) # TRUE
#' is_methylation(c("sample1.CEL")) # FALSE
is_methylation <- function(files) {
  has_bpm <- any(grepl("\\.bpm$", files, ignore.case = TRUE))
  has_idat <- any(grepl("\\.idat(\\.gz)?$", files, ignore.case = TRUE))
  return(has_idat && has_bpm)
}

#' Detect platform type from filelist.txt
#'
#' Parses GEO filelist.txt and infers the microarray platform type
#' based on file extension patterns.
#'
#' @param filelist_path Path to GEO filelist.txt file
#' @return Named list with:
#'   - platform: Character string of detected platform type
#'   - files: Character vector of parsed filenames
#'   - file_types: Named logical vector of detected file types
#'
#' @examples
#' result <- detect_platform("data/GSE12345/suppl/filelist.txt")
#' result$platform # "Affymetrix_microarray"
detect_platform <- function(filelist_path) {
  
  # Read filelist.txt (GEO format has 6 columns minimum)
  df <- tryCatch({
    read.table(
      filelist_path,
      header = FALSE,
      fill = TRUE,
      stringsAsFactors = FALSE,
      quote = ""
    )
  }, error = function(e) {
    return(NULL)
  })
  
  if (is.null(df) || nrow(df) == 0) {
    return(list(
      platform = "Unknown",
      files = character(0),
      file_types = list(
        has_CEL = FALSE,
        has_GPR = FALSE,
        has_IDAT = FALSE,
        has_BPM = FALSE,
        has_TXT = FALSE,
        has_CSV = FALSE,
        has_XLSX = FALSE,
        has_matrix = FALSE
      )
    ))
  }
  
  # Extract filename column (column 2 in GEO filelist format)
  if (ncol(df) >= 6) {
    filenames <- df[, 2]
  } else {
    filenames <- df[, 1]
  }
  
  filenames <- filenames[!is.na(filenames) & filenames != ""]
  
  # Detect file types using regex patterns
  file_types <- list(
    has_CEL    = any(grepl("\\.CEL(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_GPR    = any(grepl("\\.GPR(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_IDAT   = any(grepl("\\.idat(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_BPM    = any(grepl("\\.bpm$", filenames, ignore.case = TRUE)),
    has_TXT    = any(grepl("\\.txt(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_CSV    = any(grepl("\\.csv(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_XLSX   = any(grepl("\\.xlsx(\\.gz)?$", filenames, ignore.case = TRUE)),
    has_matrix = any(grepl("series_matrix", filenames, ignore.case = TRUE))
  )
  
  # Infer platform type following priority order
  platform <- if (file_types$has_CEL) {
    "Affymetrix_microarray"
  } else if (file_types$has_GPR) {
    "Agilent_microarray"
  } else if (file_types$has_IDAT && file_types$has_BPM) {
    "Methylation_array"
  } else if (file_types$has_IDAT && !file_types$has_BPM) {
    "Illumina_expression_array"
  } else if (file_types$has_TXT && !file_types$has_IDAT && !file_types$has_CEL && !file_types$has_GPR) {
    "TXT_array"
  } else if (file_types$has_matrix) {
    "Matrix_only"
  } else {
    "Unknown"
  }
  
  return(list(
    platform = platform,
    files = filenames,
    file_types = file_types
  ))
}

#' Detect if TXT files are Agilent Feature Extraction format
#'
#' @param raw_dir Path to RAW directory containing extracted files
#' @return Named list with:
#'   - is_agilent_fe: Logical TRUE if Agilent FE TXT detected
#'   - sample_files: Character vector of Agilent FE TXT files
#'
#' @examples
#' result <- detect_agilent_txt("GSE12345/RAW/")
detect_agilent_txt <- function(raw_dir) {
  if (!dir.exists(raw_dir)) {
    return(list(is_agilent_fe = FALSE, sample_files = character(0)))
  }
  
  # Find all TXT files (exclude GPR files)
  txt_files <- list.files(raw_dir, pattern = "\\.txt(\\.gz)?$",
                           full.names = TRUE, ignore.case = TRUE)
  txt_files <- txt_files[!grepl("\\.gpr", txt_files, ignore.case = TRUE)]
  
  if (length(txt_files) == 0) {
    return(list(is_agilent_fe = FALSE, sample_files = character(0)))
  }
  
    # Check header of first file for Agilent FE columns
    header <- tryCatch({
      if (grepl("\\.gz$", txt_files[1])) {
        readLines(gzfile(txt_files[1]), n = 1)
      } else {
        readLines(txt_files[1], n = 1)
      }
    }, error = function(e) "")
  # Agilent FE characteristic columns
  agilent_cols <- c("ProbeName", "GeneName", "gTotalGeneSignal", 
                    "gTotalProbeSignal", "gMeanSignal", "gProcessedSignal",
                    "ControlType", "gIsGeneDetected", "gIsSaturated")
  
  is_agilent <- any(sapply(agilent_cols, function(col) grepl(col, header)))
  
  return(list(
    is_agilent_fe = is_agilent,
    sample_files = if (is_agilent) txt_files else character(0)
  ))
}