# ===================================================
## fetch_geo.R - Main GEO Microarray Data Fetch Script
## 
## Smart fallback: processed matrix → raw files → metadata
## Supports multiple platforms with per-GPL output files
## 
## Dependencies: platform_detect.R, validate.R
## ===================================================

# ===================================================
## Source Dependencies
## ===================================================
# Get script directory for relative sourcing
script_dir <- tryCatch({
  # Works when script is sourced
  dirname(sys.frame(1)$ofile)
}, error = function(e) {
  # Fallback: assume current working directory
  getwd()
})

# Source platform detection and validation modules
source(file.path(script_dir, "platform_detect.R"))
source(file.path(script_dir, "validate.R"))

# ===================================================
## Required Libraries
## ===================================================
library(GEOquery)
library(Biobase)
library(dplyr)
library(tidyr)
library(stringr)
library(tibble)

# ===================================================
## Error Codes (from ERROR_CODES.md)
## ===================================================
ERROR_CODES <- list(
  E001 = list(code = "E001", message = "No suppl directory", action = "Skip GSE"),
  E002 = list(code = "E002", message = "Methylation BPM present", action = "Skip GSE"),
  E003 = list(code = "E003", message = "No series matrix", action = "Fallback to raw"),
  E004 = list(code = "E004", message = "No raw files", action = "Return metadata only"),
  E005 = list(code = "E005", message = "Corrupted CEL file", action = "Log and skip file"),
  E006 = list(code = "E006", message = "GPL not found", action = "Auto-download"),
  E007 = list(code = "E007", message = "Rate limit exceeded", action = "Retry with backoff")
)

# ===================================================
## Rate Limiter
## Default: 3 req/s, With API key: 10 req/s
## ===================================================
rate_limiter <- local({
  last_request_time <- NULL
  min_interval <- NULL
  
  init <- function(api_key = NULL) {
    # Default: 3 req/s (333ms interval)
    # With API key: 10 req/s (100ms interval)
    min_interval <<- if (!is.null(api_key)) 0.1 else 0.333
    last_request_time <<- NULL
  }
  
  wait <- function() {
    if (is.null(min_interval)) init()
    
    if (!is.null(last_request_time)) {
      elapsed <- as.numeric(Sys.time() - last_request_time, units = "secs")
      if (elapsed < min_interval) {
        Sys.sleep(min_interval - elapsed)
      }
    }
    last_request_time <<- Sys.time()
  }
  
  list(init = init, wait = wait)
})

# ===================================================
## Proxy Handler
## Uses localhost:1086 from 8-GEO patterns
## ===================================================
proxy_handler <- local({
  set_proxy <- function(proxy = "http://localhost:1086") {
    Sys.setenv(http_proxy = proxy, https_proxy = proxy)
  }
  
  unset_proxy <- function() {
    Sys.unsetenv(c("http_proxy", "https_proxy"))
  }
  
  list(set = set_proxy, unset = unset_proxy)
})

# ===================================================
## Normalize Expression Matrix
## from 8-GEO/3-数据清洗TXT.R patterns
## ===================================================
detect_expr_type <- function(x) {
  q <- quantile(x, probs = c(0.01, 0.5, 0.99), na.rm = TRUE)
  mean_x <- mean(x, na.rm = TRUE)
  
  if (q[3] > 100) return("raw")
  if (abs(mean_x) < 0.5 && q[3] < 10 && q[1] > -10) return("centered")
  return("log")
}

normalize_expr_matrix <- function(x) {
  type <- detect_expr_type(x)
  
  if (type == "raw") x <- log2(x + 1)
  
  # Ensure non-negative
  min_val <- min(x, na.rm = TRUE)
  if (min_val < 0) x <- x - min_val
  
  x
}

# ===================================================
## Get GPL Annotation Table
## Downloads GPL annotation and returns probe-to-gene mapping
## ===================================================
#' Get GPL annotation table for probe-to-gene mapping
#'
#' Downloads GPL annotation from GEO using GEOquery and returns
#' a data frame with probe ID to gene symbol mapping.
#'
#' @param gpl_id GPL identifier (e.g., "GPL570")
#' @param destdir Optional directory to cache downloaded GPL file
#' @return data.frame with columns: ID, Gene Symbol (or NULL if failed)
#'
#' @examples
#' gpl_table <- get_gpl_annotation("GPL570")
#' gpl_table <- get_gpl_annotation("GPL570", "platforms/")
get_gpl_annotation <- function(gpl_id, destdir = NULL) {
  # Validate GPL ID
  if (is.null(gpl_id) || gpl_id == "") {
    message("GPL ID is NULL or empty")
    return(NULL)
  }
  
  # Normalize GPL ID
  gpl_id <- toupper(gpl_id)
  if (!grepl("^GPL", gpl_id)) {
    gpl_id <- paste0("GPL", gpl_id)
  }
  
  # Check cache first if destdir provided
  if (!is.null(destdir) && dir.exists(destdir)) {
    cache_file <- file.path(destdir, paste0(gpl_id, "_annotation.rds"))
    if (file.exists(cache_file)) {
      message("Loading cached GPL annotation: ", gpl_id)
      return(readRDS(cache_file))
    }
  }
  
  # Download GPL annotation
  message("Downloading GPL annotation: ", gpl_id)
  gpl <- tryCatch({
    getGEO(gpl_id)
  }, error = function(e) {
    message("Failed to download GPL ", gpl_id, ": ", e$message)
    NULL
  })
  
  if (is.null(gpl)) {
    return(NULL)
  }
  
  # Extract annotation table
  gpl_table <- tryCatch({
    Table(gpl)
  }, error = function(e) {
    message("Failed to extract GPL table: ", e$message)
    NULL
  })
  
  if (is.null(gpl_table)) {
    return(NULL)
  }
  
  # Select relevant columns (ID and Gene Symbol)
  # Different GPL platforms may have different column names
  col_names <- colnames(gpl_table)
  
  # Find ID column
  id_col <- which(toupper(col_names) == "ID")[1]
  if (is.na(id_col)) {
    message("Cannot find ID column in GPL annotation")
    return(NULL)
  }
  
  # Find Gene Symbol column - try each preferred name in order
  # (order matters because some GPLs have both GENE and GENE_SYMBOL columns)
  preferred_cols <- c("GENE_SYMBOL", "SYMBOL", "GENE NAME", "GENE SYMBOL (EXTERNAL)", "GENESYMBOL", "GENE_NAME", "GENE SYMBOL")
  gene_col <- NA
  for (pref_col in preferred_cols) {
    idx <- which(toupper(col_names) == toupper(pref_col))[1]
    if (!is.na(idx)) {
      gene_col <- idx
      break
    }
  }
  
  if (is.na(gene_col)) {
    message("Cannot find Gene Symbol column in GPL annotation. Available columns: ", paste(col_names[1:min(10, length(col_names))], collapse=", "))
    # Return with ID only if no gene column
    gpl_table <- gpl_table[, id_col, drop = FALSE]
    colnames(gpl_table)[1] <- "probe_id"
    return(gpl_table)
  }
  
  # Extract ID and Gene Symbol columns
  result <- data.frame(
    probe_id = as.character(gpl_table[, id_col]),
    gene_symbol = as.character(gpl_table[, gene_col]),
    stringsAsFactors = FALSE
  )
  
  # Remove rows with no gene symbol
  result <- result[result$gene_symbol != "" & !is.na(result$gene_symbol), ]
  
  # Cache if destdir provided
  if (!is.null(destdir) && dir.exists(destdir)) {
    cache_file <- file.path(destdir, paste0(gpl_id, "_annotation.rds"))
    saveRDS(result, cache_file)
    message("Cached GPL annotation to: ", cache_file)
  }
  
  return(result)
}

# ===================================================
## Aggregate Probe-level to Gene-level Expression
## Handles multiple probes mapping to same gene
## ===================================================
#' Aggregate probe-level expression to gene-level
#'
#' Joins expression matrix with GPL annotation and aggregates
#' multiple probes to gene level using mean.
#'
#' @param expr_matrix Expression matrix (probes as rows, samples as columns)
#' @param gpl_table GPL annotation table from get_gpl_annotation()
#' @return data.frame with gene-level expression (gene_symbol, sample1, sample2, ...)
#'
#' @examples
#' expr_gene <- aggregate_probe_to_gene(expr_matrix, gpl_table)
aggregate_probe_to_gene <- function(expr_matrix, gpl_table) {
  # Validate inputs
  if (is.null(expr_matrix) || nrow(expr_matrix) == 0) {
    message("Expression matrix is NULL or empty")
    return(NULL)
  }
  
  if (is.null(gpl_table) || nrow(gpl_table) == 0) {
    message("GPL table is NULL or empty")
    return(NULL)
  }
  
  # Check required columns in gpl_table
  if (!"probe_id" %in% colnames(gpl_table) || !"gene_symbol" %in% colnames(gpl_table)) {
    message("GPL table missing required columns: probe_id, gene_symbol")
    return(NULL)
  }
  
  # Convert expression matrix to data.frame if needed
  if (is.matrix(expr_matrix)) {
    expr_df <- as.data.frame(expr_matrix)
    expr_df$probe_id <- rownames(expr_matrix)
  } else if (is.data.frame(expr_matrix)) {
    expr_df <- expr_matrix
  } else {
    message("Expression matrix must be matrix or data.frame")
    return(NULL)
  }
  
  # Prepare probe-to-gene mapping
  # Handle " /// " separated gene symbols (split them)
  probe2gene <- gpl_table %>%
    select(probe_id, gene_symbol) %>%
    mutate(gene_symbol = str_split(gene_symbol, " /// ")) %>%
    unnest(gene_symbol) %>%
    mutate(gene_symbol = trimws(gene_symbol)) %>%
    filter(gene_symbol != "" & !is.na(gene_symbol))
  
  # Melt expression matrix (wide to long)
  expr_long <- expr_df %>%
    pivot_longer(cols = -probe_id, names_to = "sample", values_to = "expr")
  
  # Join with gene mapping and aggregate
  expr_gene <- expr_long %>%
    inner_join(probe2gene, by = "probe_id") %>%
    group_by(gene_symbol, sample) %>%
    summarise(expr = mean(expr, na.rm = TRUE), .groups = "drop") %>%
    mutate(expr = ifelse(is.nan(expr), NA_real_, expr)) %>%
    pivot_wider(names_from = sample, values_from = expr)
  
  # Convert to data.frame with gene_symbol as first column
  expr_gene <- as.data.frame(expr_gene)
  
  return(expr_gene)
}

# ===================================================
## Null Coalescing Operator
## ===================================================
`%||%` <- function(x, y) if (is.null(x)) y else x

# ===================================================
## Main Fetch Function
## 
## @param gse_id GEO Series identifier (e.g., "GSE12345")
## @param output_dir Directory for saving files (default: current directory)
## @param api_key NCBI API key for higher rate limits (optional)
## 
## @return list with:
##   - status: "success_matrix"|"success_raw"|"metadata_only"|"error"|"skipped_methylation"
##   - gse_id: The GSE identifier
##   - probe_file: Path(s) to probe-level expression files
##   - gene_file: Path(s) to gene-level expression files
##   - metadata: Dataset metadata by platform
##   - warnings: Non-fatal warnings
##   - errors: Error messages
##   - platforms: Platform detection results
## ===================================================
fetch_geo <- function(gse_id, output_dir = NULL, api_key = NULL) {
  
  # Initialize rate limiter
  rate_limiter$init(api_key)
  
  # Set output directory
  if (is.null(output_dir)) {
    output_dir <- getwd()
  }
  
  # Create output directory
  out_gse_dir <- file.path(output_dir, gse_id)
  dir.create(out_gse_dir, recursive = TRUE, showWarnings = FALSE)
  
  # Initialize result structure
  result <- list(
    status = "unknown",
    gse_id = gse_id,
    probe_file = NULL,
    gene_file = NULL,
    metadata = list(),
    warnings = list(),
    errors = list(),
    platforms = list()
  )
  
  # ===================================================
  ## Step 1: Check for suppl directory
  ## ===================================================
  suppl_dir <- file.path(out_gse_dir, "suppl")
  
  if (!dir.exists(suppl_dir)) {
    # Try to fetch from GEO
    proxy_handler$set()
    rate_limiter$wait()
    
    gse_geo <- tryCatch({
      getGEOSuppFiles(gse_id, makeDirectory = FALSE, baseDir = output_dir)
    }, error = function(e) {
      message("Failed to download suppl files: ", e$message)
      NULL
    })
    
    proxy_handler$unset()
    
    if (is.null(gse_geo) || !dir.exists(suppl_dir)) {
      result$errors <- c(result$errors, ERROR_CODES$E001$message)
      result$status <- "error"
      return(result)
    }
  }
  
  # ===================================================
  ## Step 2: Check for methylation data (BPM files)
  ## Uses platform_detect.R's detect_platform()
  ## ===================================================
  filelist_path <- file.path(suppl_dir, "filelist.txt")
  platform_info <- detect_platform(filelist_path)
  
  if (isTRUE(platform_info$file_types$has_BPM)) {
    result$errors <- c(result$errors, ERROR_CODES$E002$message)
    result$status <- "skipped_methylation"
    return(result)
  }
  
  result$platforms <- platform_info
  
  # ===================================================
  ## Step 3: Try processed series matrix first
  ## Primary fallback approach
  ## ===================================================
  proxy_handler$set()
  rate_limiter$wait()
  
  gse_matrix <- tryCatch({
    getGEO(gse_id, GSEMatrix = TRUE)
  }, error = function(e) {
    message("Failed to get series matrix: ", e$message)
    NULL
  })
  
  proxy_handler$unset()
  
  if (!is.null(gse_matrix) && length(gse_matrix) > 0) {
    # Successfully got processed data
    result$status <- "success_matrix"
    result$warnings <- c(result$warnings, "Using processed series matrix")
    
    # Process each platform (ExpressionSet)
    # Handles multiple GPLs with _[GPL] suffix
    for (i in seq_along(gse_matrix)) {
      eset <- gse_matrix[[i]]
      gpl_id <- annotation(eset)
      
      # Platform suffix for multi-platform datasets
      gpl_suffix <- if (length(gse_matrix) > 1) paste0("_", gpl_id) else ""
      
      expr_matrix <- exprs(eset)
      
      # Validate expression matrix using validate.R
      validation <- validate_expr_matrix(expr_matrix)
      if (!validation$valid) {
        result$warnings <- c(result$warnings, paste("Validation warning:", validation$reason))
      }
      
      # Normalize
      expr_matrix <- normalize_expr_matrix(expr_matrix)
      colnames(expr_matrix) <- make.names(colnames(expr_matrix), unique = TRUE)
      
      # Save probe-level expression
      probe_file <- file.path(out_gse_dir, paste0("expr_probe_", gse_id, gpl_suffix, ".csv"))
      write.csv(expr_matrix, file = probe_file, row.names = TRUE)
      result$probe_file <- c(result$probe_file, probe_file)
      
      # Extract metadata
      pdata <- pData(eset)
      fdata <- fData(eset)
      
      # Get gene symbol column
      gene_col <- intersect(
        colnames(fdata),
        c("Gene Symbol", "GENE_SYMBOL", "Symbol", "gene_assignment", "GENE_NAME")
      )[1]
      
      if (!is.na(gene_col)) {
        # Build probe-to-gene mapping
        probe2gene <- fdata %>%
          select(probe_id = ID, gene_symbol = all_of(gene_col)) %>%
          filter(!is.na(gene_symbol), gene_symbol != "") %>%
          mutate(gene_symbol = str_split(gene_symbol, " /// ")) %>%
          unnest(gene_symbol)
        
        # Aggregate to gene level
        expr_df <- as.data.frame(expr_matrix)
        expr_df$probe_id <- rownames(expr_df)
        
        expr_gene <- expr_df %>%
          pivot_longer(-probe_id, names_to = "sample", values_to = "expr") %>%
          inner_join(probe2gene, by = "probe_id") %>%
          group_by(gene_symbol, sample) %>%
          summarise(expr = mean(expr, na.rm = TRUE), .groups = "drop") %>%
          pivot_wider(names_from = sample, values_from = expr) %>%
          as.data.frame()
        
        rownames(expr_gene) <- expr_gene$gene_symbol
        expr_gene$gene_symbol <- NULL
        
        # Save gene-level expression
        gene_file <- file.path(out_gse_dir, paste0("expr_gene_", gse_id, gpl_suffix, ".csv"))
        write.csv(expr_gene, file = gene_file, row.names = TRUE)
        result$gene_file <- c(result$gene_file, gene_file)
      } else {
        result$warnings <- c(result$warnings, "No gene symbol column found, probe-level only")
      }
      
      # Store metadata
      result$metadata[[gpl_id]] <- list(
        title = experimentData(eset)@title %||% NA,
        summary = experimentData(eset)@abstract %||% NA,
        organism = experimentData(eset)@other$sample_taxid %||% NA,
        platform = gpl_id,
        n_samples = ncol(expr_matrix),
        n_probes = nrow(expr_matrix)
      )
    }
    
    return(result)
  }
  
  # ===================================================
  ## Step 4: Fallback to raw CEL files (Affymetrix)
  ## E003: No series matrix - fallback to raw
  ## ===================================================
  result$warnings <- c(result$warnings, ERROR_CODES$E003$message)
  
  raw_dir <- file.path(suppl_dir, "RAW")
  tar_files <- list.files(suppl_dir, pattern = "_RAW\\.tar$", full.names = TRUE)
  
  if (length(tar_files) > 0) {
    # Extract RAW.tar
    if (!dir.exists(raw_dir)) dir.create(raw_dir, recursive = TRUE)
    if (length(list.files(raw_dir)) == 0) {
      untar(tar_files[1], exdir = raw_dir)
    }
  }
  
  # Find CEL files
  cel_files <- list.files(raw_dir, pattern = "\\.CEL(\\.gz)?$", full.names = TRUE, recursive = TRUE)

# Check for Agilent FE TXT files (after CEL check fails)
if (length(cel_files) == 0) {
    agilent_fe <- detect_agilent_txt(raw_dir)
    
    if (agilent_fe$is_agilent_fe) {
      message("Found Agilent Feature Extraction TXT files...")
      
      if (requireNamespace("limma", quietly = TRUE)) {
        agilent_result <- tryCatch({
          # Read Agilent FE TXT files using limma
          rg_list <- limma::read.maimages(
            agilent_fe$sample_files,
            source = "agilent",
            green.only = TRUE  # for single-channel
          )
          
          # Extract expression matrix (use gMeanSignal or gProcessedSignal)
          if ("R" %in% names(rg_list)) {
            expr_matrix <- rg_list$R
          } else if ("M" %in% names(rg_list)) {
            expr_matrix <- rg_list$M
          } else {
            # Try to extract from available columns
            expr_matrix <- rg_list$genes
          }
          
          if (!is.null(expr_matrix) && nrow(expr_matrix) > 0) {
            # Normalize expression matrix
            expr_matrix <- normalize_expr_matrix(as.matrix(expr_matrix))
            
            # Write probe file
            probe_file <- file.path(out_gse_dir, paste0("expr_probe_", gse_id, ".csv"))
            write.csv(expr_matrix, file = probe_file, row.names = TRUE)
            result$probe_file <- probe_file
            
            # Try to aggregate to gene level
            gpl_id <- platform_info$platform_id %||% NA
            if (!is.na(gpl_id)) {
              gpl_table <- get_gpl_annotation(gpl_id)
              if (!is.null(gpl_table)) {
                expr_gene <- aggregate_probe_to_gene(expr_matrix, gpl_table)
                if (validate_gene_expression(expr_gene)) {
                  gene_file <- file.path(out_gse_dir, paste0("expr_gene_", gse_id, ".csv"))
                  write.csv(expr_gene, file = gene_file, row.names = TRUE)
                  result$gene_file <- gene_file
                }
              }
            }
            
            # Fallback: use probe data as gene data
            if (is.null(result$gene_file)) {
              gene_file <- file.path(out_gse_dir, paste0("expr_gene_", gse_id, ".csv"))
              write.csv(expr_matrix, file = gene_file, row.names = TRUE)
              result$gene_file <- gene_file
            }
            
            result$status <- "success_raw"
            result$warnings <- c(result$warnings, "Using Agilent FE TXT files")
            
            # Get metadata
            proxy_handler$set()
            gse_meta <- tryCatch(getGEO(gse_id, GSEMatrix = FALSE), error = function(e) NULL)
            proxy_handler$unset()
            
            if (!is.null(gse_meta)) {
              result$metadata$basic <- list(
                title = Meta(gse_meta)$title %||% NA,
                summary = Meta(gse_meta)$summary %||% NA,
                n_samples = ncol(expr_matrix),
                n_probes = nrow(expr_matrix)
              )
            }
            
            return(result)
          }
        }, error = function(e) {
          message("Failed to process Agilent FE TXT: ", e$message)
          NULL
        })
        
        if (!is.null(agilent_result)) {
          return(agilent_result)
        }
      }
    }
  }
  
  if (length(cel_files) == 0) {
    # No raw files available - E004: Return metadata only
    result$warnings <- c(result$warnings, ERROR_CODES$E004$message)
    result$status <- "metadata_only"
    
    # Return basic metadata
    proxy_handler$set()
    rate_limiter$wait()
    
    gse_meta <- tryCatch({
      getGEO(gse_id, GSEMatrix = FALSE)
    }, error = function(e) NULL)
    
    proxy_handler$unset()
    
    if (!is.null(gse_meta)) {
      result$metadata$basic <- list(
        title = Meta(gse_meta)$title %||% NA,
        summary = Meta(gse_meta)$summary %||% NA
      )
    }
    
    return(result)
  }
  
  # ===================================================
  ## Step 5: Process CEL files with oligo/RMA
  ## ===================================================
  # Check for corrupted CEL files using validate.R
  cel_validation <- sapply(cel_files, function(f) {
    val <- validate_cel_integrity(f)
    if (!val$valid) {
      message("Bad CEL file: ", basename(f), " - ", val$reason)
    }
    val$valid
  })
  
  good_cel_files <- cel_files[cel_validation]
  bad_cel_files <- basename(cel_files[!cel_validation])
  
  if (length(bad_cel_files) > 0) {
    result$warnings <- c(result$warnings, paste(ERROR_CODES$E005$message, ":", paste(bad_cel_files, collapse = ", ")))
    writeLines(bad_cel_files, file.path(out_gse_dir, paste0("bad_cel_", gse_id, ".txt")))
  }
  
  if (length(good_cel_files) == 0) {
    result$errors <- c(result$errors, "All CEL files are corrupted")
    result$status <- "error"
    return(result)
  }
  
  # RMA normalization
  if (requireNamespace("oligo", quietly = TRUE)) {
    raw_data <- oligo::read.celfiles(good_cel_files)
    eset <- oligo::rma(raw_data)
    expr_matrix <- exprs(eset)
    colnames(expr_matrix) <- str_remove(basename(colnames(expr_matrix)), "\\.CEL(\\.gz)?$")
    
    # Get GPL annotation
    proxy_handler$set()
    rate_limiter$wait()
    
    gse_obj <- tryCatch({
      getGEO(gse_id, GSEMatrix = FALSE)
    }, error = function(e) NULL)
    
    proxy_handler$unset()
    
    if (!is.null(gse_obj)) {
      gpl_ids <- names(GPLList(gse_obj))
      
      if (length(gpl_ids) >= 1) {
        gpl_id <- gpl_ids[1]
        
        # Get GPL table
        proxy_handler$set()
        rate_limiter$wait()
        
        gpl <- tryCatch({
          getGEO(gpl_id)
        }, error = function(e) {
          result$warnings <- c(result$warnings, ERROR_CODES$E006$message)
          NULL
        })
        
        proxy_handler$unset()
        
        if (!is.null(gpl)) {
          gpl_table <- Table(gpl)
          
          # Build probe-to-gene mapping
          gene_col <- intersect(
            colnames(gpl_table),
            c("Gene Symbol", "GENE_SYMBOL", "Symbol", "gene_assignment")
          )[1]
          
          if (!is.na(gene_col)) {
            probe2gene <- gpl_table %>%
              select(probe_id = ID, gene_symbol = all_of(gene_col)) %>%
              filter(!is.na(gene_symbol), gene_symbol != "") %>%
              mutate(gene_symbol = str_split(gene_symbol, " /// ")) %>%
              unnest(gene_symbol)
            
            # Aggregate to gene level
            expr_df <- as.data.frame(expr_matrix)
            expr_df$probe_id <- rownames(expr_df)
            
            expr_gene <- expr_df %>%
              pivot_longer(-probe_id, names_to = "sample", values_to = "expr") %>%
              inner_join(probe2gene, by = "probe_id") %>%
              group_by(gene_symbol, sample) %>%
              summarise(expr = mean(expr, na.rm = TRUE), .groups = "drop") %>%
              pivot_wider(names_from = sample, values_from = expr) %>%
              as.data.frame()
            
            rownames(expr_gene) <- expr_gene$gene_symbol
            expr_gene$gene_symbol <- NULL
            
            # Save
            gene_file <- file.path(out_gse_dir, paste0("expr_gene_", gse_id, ".csv"))
            write.csv(expr_gene, file = gene_file, row.names = TRUE)
            result$gene_file <- gene_file
            
            result$metadata[[gpl_id]] <- list(
              platform = gpl_id,
              n_samples = ncol(expr_matrix),
              n_probes = nrow(expr_matrix)
            )
          }
        }
      }
    }
    
    # Save probe-level expression
    probe_file <- file.path(out_gse_dir, paste0("expr_probe_", gse_id, ".csv"))
    write.csv(expr_matrix, file = probe_file, row.names = TRUE)
    result$probe_file <- probe_file
    
    result$status <- "success_raw"
  } else {
    result$errors <- c(result$errors, "oligo package not available for CEL processing")
    result$status <- "error"
  }
  
  result
}

# ===================================================
## Usage Example
## ===================================================
# source("fetch_geo.R")
# result <- fetch_geo("GSE12345", output_dir = "./output", api_key = NULL)
# if (result$status == "success_matrix" || result$status == "success_raw") {
#   message("Successfully fetched data for ", result$gse_id)
#   message("Probe files: ", paste(result$probe_file, collapse = ", "))
#   message("Gene files: ", paste(result$gene_file, collapse = ", "))
# } else if (result$status == "skipped_methylation") {
#   message("Skipped methylation data")
# } else {
#   message("Errors: ", paste(result$errors, collapse = "; "))
# }
# ===================================================
## Command Line Interface
## ===================================================
if (!interactive() && sys.nframe() == 0) {
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) == 0) {
    cat("Usage: Rscript fetch_geo.R GSE_ID [OUTPUT_DIR]\n")
    quit(status = 1)
  }
  gse_id <- args[1]
  output_dir <- if (length(args) > 1) args[2] else getwd()
  result <- fetch_geo(gse_id, output_dir = output_dir)
  cat("Status:", result$status, "\n")
  if (result$status == "error") quit(status = 1)
}
