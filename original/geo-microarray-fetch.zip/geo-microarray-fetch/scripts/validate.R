# validate.R - Validation functions for geo-microarray-fetch
# 
# This script provides validation functions for data integrity checks
# throughout the microarray data fetching workflow.

#' Validate CEL file integrity
#'
#' Check if a CEL file is corrupted and can be read properly.
#' Related to error code E005: Corrupted CEL file
#'
#' @param cel_file Path to the CEL file to validate
#' @return list with 'valid' (logical) and 'reason' (character) fields
#'
#' @examples
#' result <- validate_cel_integrity("sample.CEL")
#' if (!result$valid) {
#'   message("Invalid CEL: ", result$reason)
#' }
validate_cel_integrity <- function(cel_file) {
  # Check file exists
  if (!file.exists(cel_file)) {
    return(FALSE)
  }
  
  # Check file size (empty files are invalid)
  file_size <- file.info(cel_file)$size
  if (is.na(file_size) || file_size == 0) {
    return(FALSE)
  }
  
  # Try to read the CEL file using tryCatch pattern
  # Pattern from 8-GEO/3-数据清洗1-1.R:74-84
  result <- tryCatch({
    # Load oligo package for CEL file reading
    if (!requireNamespace("oligo", quietly = TRUE)) {
      stop("Package 'oligo' is required for CEL validation")
    }
    
    # Attempt to read CEL file (consistent with fetch_geo.R)
    oligo::read.celfiles(cel_file)
    TRUE
  }, error = function(e) {
    FALSE
  }, warning = function(w) {
    # Warnings don't necessarily mean invalid
    TRUE
  })
  
  return(result)
}

#' Validate GSM ID match between expression matrix and IDAT files
#'
#' Check that GSM IDs extracted from IDAT files match the columns in the expression matrix.
#' Pattern from 8-GEO/3-数据清洗IDAT.R:132-140
#'
#' @param expr_matrix Expression matrix with samples as columns
#' @param idat_files Vector of IDAT file paths
#' @return list with 'valid' (logical) and 'reason' (character) fields
#'
#' @examples
#' result <- validate_gsm_match(expr_matrix, idat_files)
#' if (!result$valid) {
#'   message("GSM validation failed: ", result$reason)
#' }
validate_gsm_match <- function(expr_matrix, idat_files) {
  # Check inputs are not empty
  if (is.null(expr_matrix) || length(expr_matrix) == 0) {
    return(list(valid = FALSE, reason = "Expression matrix is NULL or empty"))
  }
  
  if (is.null(idat_files) || length(idat_files) == 0) {
    return(list(valid = FALSE, reason = "IDAT files vector is NULL or empty"))
  }
  
  # Extract GSM IDs from IDAT file names
  # Pattern: GSM followed by digits at the start of filename
  gsm_from_idat <- gsub("^(GSM[0-9]+).*", "\\1", basename(idat_files))
  
  # Check if extraction produced valid GSM IDs
  gsm_pattern <- "^GSM[0-9]+$"
  valid_gsm <- grepl(gsm_pattern, gsm_from_idat)
  
  if (any(!valid_gsm)) {
    invalid_count <- sum(!valid_gsm)
    return(list(
      valid = FALSE,
      reason = paste(invalid_count, "IDAT file(s) have invalid GSM ID format")
    ))
  }
  
  # Get GSM IDs from expression matrix columns
  gsm_from_matrix <- colnames(expr_matrix)
  
  # Check count match
  if (length(gsm_from_idat) != length(gsm_from_matrix)) {
    return(list(
      valid = FALSE,
      reason = paste(
        "GSM count mismatch: IDAT files =", length(gsm_from_idat),
        ", expression columns =", length(gsm_from_matrix)
      )
    ))
  }
  
  # Check for duplicates in IDAT-derived GSM IDs
  if (any(duplicated(gsm_from_idat))) {
    dup_count <- sum(duplicated(gsm_from_idat))
    return(list(
      valid = FALSE,
      reason = paste("Duplicated GSM IDs detected in IDAT files:", dup_count, "duplicates")
    ))
  }
  
  # Check for duplicates in matrix GSM IDs
  if (any(duplicated(gsm_from_matrix))) {
    dup_count <- sum(duplicated(gsm_from_matrix))
    return(list(
      valid = FALSE,
      reason = paste("Duplicated GSM IDs detected in expression matrix:", dup_count, "duplicates")
    ))
  }
  
  return(list(valid = TRUE, reason = "GSM IDs match between expression matrix and IDAT files"))
}

#' Validate GPL platform file existence
#'
#' Check if the GPL annotation file exists in the specified directory.
#' Related to error code E006: GPL not found
#'
#' @param gpl_id GPL identifier (e.g., "GPL570")
#' @param platform_dir Directory where GPL files are stored
#' @return list with 'valid' (logical) and 'reason' (character) fields
#'
#' @examples
#' result <- validate_gpl_exists("GPL570", "platforms/")
#' if (!result$valid) {
#'   message("GPL validation failed: ", result$reason)
#' }
validate_gpl_exists <- function(gpl_id, platform_dir) {
  # Check inputs
  if (is.null(gpl_id) || gpl_id == "") {
    return(list(valid = FALSE, reason = "GPL ID is NULL or empty"))
  }
  
  if (is.null(platform_dir) || platform_dir == "") {
    return(list(valid = FALSE, reason = "Platform directory is NULL or empty"))
  }
  
  # Normalize GPL ID (ensure GPL prefix)
  gpl_id <- toupper(gpl_id)
  if (!grepl("^GPL", gpl_id)) {
    gpl_id <- paste0("GPL", gpl_id)
  }
  
  # Check if platform directory exists
  if (!dir.exists(platform_dir)) {
    return(list(
      valid = FALSE,
      reason = paste("Platform directory does not exist:", platform_dir)
    ))
  }
  
  # Check for GPL file with various possible extensions
  possible_files <- c(
    file.path(platform_dir, paste0(gpl_id, ".soft")),
    file.path(platform_dir, paste0(gpl_id, ".soft.gz")),
    file.path(platform_dir, paste0(gpl_id, ".txt")),
    file.path(platform_dir, paste0(gpl_id, ".txt.gz")),
    file.path(platform_dir, gpl_id, paste0(gpl_id, ".soft")),
    file.path(platform_dir, gpl_id, paste0(gpl_id, ".soft.gz"))
  )
  
  existing_file <- NULL
  for (f in possible_files) {
    if (file.exists(f)) {
      existing_file <- f
      break
    }
  }
  
  if (is.null(existing_file)) {
    return(list(
      valid = FALSE,
      reason = paste("GPL file not found:", gpl_id, "in", platform_dir)
    ))
  }
  
  # Check file is not empty
  file_size <- file.info(existing_file)$size
  if (is.na(file_size) || file_size == 0) {
    return(list(
      valid = FALSE,
      reason = paste("GPL file exists but is empty:", existing_file)
    ))
  }
  
  return(list(
    valid = TRUE,
    reason = paste("GPL file found:", existing_file)
  ))
}

#' Validate expression matrix
#'
#' Check that an expression matrix is valid: non-empty, non-negative values,
#' and has proper structure.
#'
#' @param matrix Expression matrix to validate
#' @return list with 'valid' (logical) and 'reason' (character) fields
#'
#' @examples
#' result <- validate_expr_matrix(expr_matrix)
#' if (!result$valid) {
#'   message("Expression matrix validation failed: ", result$reason)
#' }
validate_expr_matrix <- function(matrix) {
  # Check if input is NULL
  if (is.null(matrix)) {
    return(list(valid = FALSE, reason = "Expression matrix is NULL"))
  }
  
  # Check if input is a matrix or data frame
  if (!is.matrix(matrix) && !is.data.frame(matrix)) {
    return(list(
      valid = FALSE,
      reason = paste("Expected matrix or data.frame, got:", class(matrix)[1])
    ))
  }
  
  # Convert to matrix for consistent handling
  if (is.data.frame(matrix)) {
    numeric_cols <- sapply(matrix, is.numeric)
    if (!all(numeric_cols)) {
      non_numeric <- sum(!numeric_cols)
      return(list(
        valid = FALSE,
        reason = paste("Matrix contains", non_numeric, "non-numeric columns")
      ))
    }
    matrix <- as.matrix(matrix)
  }
  
  # Check if empty
  if (nrow(matrix) == 0) {
    return(list(valid = FALSE, reason = "Expression matrix has 0 rows (empty)"))
  }
  
  if (ncol(matrix) == 0) {
    return(list(valid = FALSE, reason = "Expression matrix has 0 columns (empty)"))
  }
  
  # Check for all NA values
  if (all(is.na(matrix))) {
    return(list(valid = FALSE, reason = "Expression matrix contains only NA values"))
  }
  
  # Check for negative values
  # Note: Some normalized data may have negative values (e.g., centered data)
  # This check flags potentially problematic raw data
  min_val <- min(matrix, na.rm = TRUE)
  if (!is.finite(min_val)) {
    return(list(valid = FALSE, reason = "Expression matrix contains infinite or non-finite values"))
  }
  
  # Check for NaN values
  nan_count <- sum(is.nan(matrix))
  if (nan_count > 0) {
    total_values <- length(matrix)
    nan_percent <- round(nan_count / total_values * 100, 2)
    return(list(
      valid = FALSE,
      reason = paste("Expression matrix contains", nan_count, "NaN values (", nan_percent, "%)")
    ))
  }
  
  # Count NA values for information
  na_count <- sum(is.na(matrix))
  total_values <- length(matrix)
  
  reason_msg <- paste(
    "Valid expression matrix:", nrow(matrix), "rows x", ncol(matrix), "columns",
    if (na_count > 0) paste(",", na_count, "NA values (", round(na_count/total_values*100, 2), "%)") else ""
  )
  
  return(list(valid = TRUE, reason = trimws(reason_msg)))
}

#' Validate gene-level expression matrix
#'
#' Check that a gene-level expression matrix is valid:
#' - Non-empty
#' - Has gene_symbol column
#' - Numeric expression values
#'
#' @param expr_gene Gene expression matrix (gene_symbol as first column)
#' @return list with 'valid' (logical) and 'reason' (character) fields
#'
#' @examples
#' result <- validate_gene_expression(expr_gene)
#' if (!result$valid) {
#'   message("Validation failed: ", result$reason)
#' }
validate_gene_expression <- function(expr_gene) {
  # Check if input is NULL
  if (is.null(expr_gene)) {
    return(list(valid = FALSE, reason = "Gene expression matrix is NULL"))
  }
  
  # Check if input is a matrix or data frame
  if (!is.matrix(expr_gene) && !is.data.frame(expr_gene)) {
    return(list(
      valid = FALSE,
      reason = paste("Expected matrix or data.frame, got:", class(expr_gene)[1])
    ))
  }
  
  # Convert to data.frame for consistent handling
  if (is.matrix(expr_gene)) {
    expr_gene <- as.data.frame(expr_gene)
  }
  
  # Check if gene_symbol column exists
  if (!"gene_symbol" %in% colnames(expr_gene)) {
    return(list(valid = FALSE, reason = "Missing 'gene_symbol' column"))
  }
  
  # Check if empty
  if (nrow(expr_gene) == 0) {
    return(list(valid = FALSE, reason = "Gene expression matrix has 0 rows"))
  }
  
  # Get expression columns (all except gene_symbol)
  expr_cols <- colnames(expr_gene)[colnames(expr_gene) != "gene_symbol"]
  
  if (length(expr_cols) == 0) {
    return(list(valid = FALSE, reason = "No expression columns found"))
  }
  
  # Check for non-finite values in expression columns
  expr_data <- expr_gene[, expr_cols, drop = FALSE]
  
  # Check for infinite values (use is.infinite to avoid false positive with NA)
  has_inf <- any(sapply(expr_data, function(x) any(is.infinite(x))))
  if (has_inf) {
    return(list(valid = FALSE, reason = "Expression matrix contains infinite values"))
  }
  
  # Check for NaN values
  nan_counts <- sapply(expr_data, function(x) sum(is.nan(x)))
  if (any(nan_counts > 0)) {
    total_values <- sum(sapply(expr_data, length))
    nan_percent <- round(sum(nan_counts) / total_values * 100, 2)
    return(list(
      valid = FALSE,
      reason = paste("Expression matrix contains", sum(nan_counts), "NaN values (", nan_percent, "%)")
    ))
  }
  
  # Count NA values for information
  na_counts <- sapply(expr_data, function(x) sum(is.na(x)))
  total_values <- sum(sapply(expr_data, length))
  na_percent <- round(sum(na_counts) / total_values * 100, 2)
  
  reason_msg <- paste(
    "Valid gene expression:", nrow(expr_gene), "genes x", length(expr_cols), "samples",
    if (sum(na_counts) > 0) paste(",", sum(na_counts), "NA values (", na_percent, "%)") else ""
  )
  
  return(list(valid = TRUE, reason = trimws(reason_msg)))
}
